#ifndef __ISR_H__
#define __ISR_H__

extern void isr_wrapper_0();
extern void isr_wrapper_1();
extern void isr_wrapper_2();
extern void isr_wrapper_3();
extern void isr_wrapper_4();
extern void isr_wrapper_5();
extern void isr_wrapper_6();
extern void isr_wrapper_7();
extern void isr_wrapper_8();
extern void isr_wrapper_9();
extern void isr_wrapper_10();
extern void isr_wrapper_11();
extern void isr_wrapper_12();
extern void isr_wrapper_13();
extern void isr_wrapper_14();
extern void isr_wrapper_15();
extern void isr_wrapper_16();
extern void isr_wrapper_17();
extern void isr_wrapper_18();
extern void isr_wrapper_19();
extern void isr_wrapper_20();
extern void isr_wrapper_21();
extern void isr_wrapper_22();
extern void isr_wrapper_23();
extern void isr_wrapper_24();
extern void isr_wrapper_25();
extern void isr_wrapper_26();
extern void isr_wrapper_27();
extern void isr_wrapper_28();
extern void isr_wrapper_29();
extern void isr_wrapper_30();
extern void isr_wrapper_31();
extern void isr_wrapper_32();
extern void isr_wrapper_33();
extern void isr_wrapper_34();
extern void isr_wrapper_35();
extern void isr_wrapper_36();
extern void isr_wrapper_37();
extern void isr_wrapper_38();
extern void isr_wrapper_39();
extern void isr_wrapper_40();
extern void isr_wrapper_41();
extern void isr_wrapper_42();
extern void isr_wrapper_43();
extern void isr_wrapper_44();
extern void isr_wrapper_45();
extern void isr_wrapper_46();
extern void isr_wrapper_47();
extern void isr_wrapper_48();
extern void isr_wrapper_49();
extern void isr_wrapper_50();
extern void isr_wrapper_51();
extern void isr_wrapper_52();
extern void isr_wrapper_53();
extern void isr_wrapper_54();
extern void isr_wrapper_55();
extern void isr_wrapper_56();
extern void isr_wrapper_57();
extern void isr_wrapper_58();
extern void isr_wrapper_59();
extern void isr_wrapper_60();
extern void isr_wrapper_61();
extern void isr_wrapper_62();
extern void isr_wrapper_63();
extern void isr_wrapper_64();
extern void isr_wrapper_65();
extern void isr_wrapper_66();
extern void isr_wrapper_67();
extern void isr_wrapper_68();
extern void isr_wrapper_69();
extern void isr_wrapper_70();
extern void isr_wrapper_71();
extern void isr_wrapper_72();
extern void isr_wrapper_73();
extern void isr_wrapper_74();
extern void isr_wrapper_75();
extern void isr_wrapper_76();
extern void isr_wrapper_77();
extern void isr_wrapper_78();
extern void isr_wrapper_79();
extern void isr_wrapper_80();
extern void isr_wrapper_81();
extern void isr_wrapper_82();
extern void isr_wrapper_83();
extern void isr_wrapper_84();
extern void isr_wrapper_85();
extern void isr_wrapper_86();
extern void isr_wrapper_87();
extern void isr_wrapper_88();
extern void isr_wrapper_89();
extern void isr_wrapper_90();
extern void isr_wrapper_91();
extern void isr_wrapper_92();
extern void isr_wrapper_93();
extern void isr_wrapper_94();
extern void isr_wrapper_95();
extern void isr_wrapper_96();
extern void isr_wrapper_97();
extern void isr_wrapper_98();
extern void isr_wrapper_99();
extern void isr_wrapper_100();
extern void isr_wrapper_101();
extern void isr_wrapper_102();
extern void isr_wrapper_103();
extern void isr_wrapper_104();
extern void isr_wrapper_105();
extern void isr_wrapper_106();
extern void isr_wrapper_107();
extern void isr_wrapper_108();
extern void isr_wrapper_109();
extern void isr_wrapper_110();
extern void isr_wrapper_111();
extern void isr_wrapper_112();
extern void isr_wrapper_113();
extern void isr_wrapper_114();
extern void isr_wrapper_115();
extern void isr_wrapper_116();
extern void isr_wrapper_117();
extern void isr_wrapper_118();
extern void isr_wrapper_119();
extern void isr_wrapper_120();
extern void isr_wrapper_121();
extern void isr_wrapper_122();
extern void isr_wrapper_123();
extern void isr_wrapper_124();
extern void isr_wrapper_125();
extern void isr_wrapper_126();
extern void isr_wrapper_127();
extern void isr_wrapper_128();
extern void isr_wrapper_129();
extern void isr_wrapper_130();
extern void isr_wrapper_131();
extern void isr_wrapper_132();
extern void isr_wrapper_133();
extern void isr_wrapper_134();
extern void isr_wrapper_135();
extern void isr_wrapper_136();
extern void isr_wrapper_137();
extern void isr_wrapper_138();
extern void isr_wrapper_139();
extern void isr_wrapper_140();
extern void isr_wrapper_141();
extern void isr_wrapper_142();
extern void isr_wrapper_143();
extern void isr_wrapper_144();
extern void isr_wrapper_145();
extern void isr_wrapper_146();
extern void isr_wrapper_147();
extern void isr_wrapper_148();
extern void isr_wrapper_149();
extern void isr_wrapper_150();
extern void isr_wrapper_151();
extern void isr_wrapper_152();
extern void isr_wrapper_153();
extern void isr_wrapper_154();
extern void isr_wrapper_155();
extern void isr_wrapper_156();
extern void isr_wrapper_157();
extern void isr_wrapper_158();
extern void isr_wrapper_159();
extern void isr_wrapper_160();
extern void isr_wrapper_161();
extern void isr_wrapper_162();
extern void isr_wrapper_163();
extern void isr_wrapper_164();
extern void isr_wrapper_165();
extern void isr_wrapper_166();
extern void isr_wrapper_167();
extern void isr_wrapper_168();
extern void isr_wrapper_169();
extern void isr_wrapper_170();
extern void isr_wrapper_171();
extern void isr_wrapper_172();
extern void isr_wrapper_173();
extern void isr_wrapper_174();
extern void isr_wrapper_175();
extern void isr_wrapper_176();
extern void isr_wrapper_177();
extern void isr_wrapper_178();
extern void isr_wrapper_179();
extern void isr_wrapper_180();
extern void isr_wrapper_181();
extern void isr_wrapper_182();
extern void isr_wrapper_183();
extern void isr_wrapper_184();
extern void isr_wrapper_185();
extern void isr_wrapper_186();
extern void isr_wrapper_187();
extern void isr_wrapper_188();
extern void isr_wrapper_189();
extern void isr_wrapper_190();
extern void isr_wrapper_191();
extern void isr_wrapper_192();
extern void isr_wrapper_193();
extern void isr_wrapper_194();
extern void isr_wrapper_195();
extern void isr_wrapper_196();
extern void isr_wrapper_197();
extern void isr_wrapper_198();
extern void isr_wrapper_199();
extern void isr_wrapper_200();
extern void isr_wrapper_201();
extern void isr_wrapper_202();
extern void isr_wrapper_203();
extern void isr_wrapper_204();
extern void isr_wrapper_205();
extern void isr_wrapper_206();
extern void isr_wrapper_207();
extern void isr_wrapper_208();
extern void isr_wrapper_209();
extern void isr_wrapper_210();
extern void isr_wrapper_211();
extern void isr_wrapper_212();
extern void isr_wrapper_213();
extern void isr_wrapper_214();
extern void isr_wrapper_215();
extern void isr_wrapper_216();
extern void isr_wrapper_217();
extern void isr_wrapper_218();
extern void isr_wrapper_219();
extern void isr_wrapper_220();
extern void isr_wrapper_221();
extern void isr_wrapper_222();
extern void isr_wrapper_223();
extern void isr_wrapper_224();
extern void isr_wrapper_225();
extern void isr_wrapper_226();
extern void isr_wrapper_227();
extern void isr_wrapper_228();
extern void isr_wrapper_229();
extern void isr_wrapper_230();
extern void isr_wrapper_231();
extern void isr_wrapper_232();
extern void isr_wrapper_233();
extern void isr_wrapper_234();
extern void isr_wrapper_235();
extern void isr_wrapper_236();
extern void isr_wrapper_237();
extern void isr_wrapper_238();
extern void isr_wrapper_239();
extern void isr_wrapper_240();
extern void isr_wrapper_241();
extern void isr_wrapper_242();
extern void isr_wrapper_243();
extern void isr_wrapper_244();
extern void isr_wrapper_245();
extern void isr_wrapper_246();
extern void isr_wrapper_247();
extern void isr_wrapper_248();
extern void isr_wrapper_249();
extern void isr_wrapper_250();
extern void isr_wrapper_251();
extern void isr_wrapper_252();
extern void isr_wrapper_253();
extern void isr_wrapper_254();
extern void isr_wrapper_255();

void *isr_fun_ptrs[256] = {
   &isr_wrapper_0, &isr_wrapper_1, &isr_wrapper_2, &isr_wrapper_3,
   &isr_wrapper_4, &isr_wrapper_5, &isr_wrapper_6, &isr_wrapper_7,
   &isr_wrapper_8, &isr_wrapper_9, &isr_wrapper_10, &isr_wrapper_11,
   &isr_wrapper_12, &isr_wrapper_13, &isr_wrapper_14, &isr_wrapper_15,
   &isr_wrapper_16, &isr_wrapper_17, &isr_wrapper_18, &isr_wrapper_19,
   &isr_wrapper_20, &isr_wrapper_21, &isr_wrapper_22, &isr_wrapper_23,
   &isr_wrapper_24, &isr_wrapper_25, &isr_wrapper_26, &isr_wrapper_27,
   &isr_wrapper_28, &isr_wrapper_29, &isr_wrapper_30, &isr_wrapper_31,
   &isr_wrapper_32, &isr_wrapper_33, &isr_wrapper_34, &isr_wrapper_35,
   &isr_wrapper_36, &isr_wrapper_37, &isr_wrapper_38, &isr_wrapper_39,
   &isr_wrapper_40, &isr_wrapper_41, &isr_wrapper_42, &isr_wrapper_43,
   &isr_wrapper_44, &isr_wrapper_45, &isr_wrapper_46, &isr_wrapper_47,
   &isr_wrapper_48, &isr_wrapper_49, &isr_wrapper_50, &isr_wrapper_51,
   &isr_wrapper_52, &isr_wrapper_53, &isr_wrapper_54, &isr_wrapper_55,
   &isr_wrapper_56, &isr_wrapper_57, &isr_wrapper_58, &isr_wrapper_59,
   &isr_wrapper_60, &isr_wrapper_61, &isr_wrapper_62, &isr_wrapper_63,
   &isr_wrapper_64, &isr_wrapper_65, &isr_wrapper_66, &isr_wrapper_67,
   &isr_wrapper_68, &isr_wrapper_69, &isr_wrapper_70, &isr_wrapper_71,
   &isr_wrapper_72, &isr_wrapper_73, &isr_wrapper_74, &isr_wrapper_75,
   &isr_wrapper_76, &isr_wrapper_77, &isr_wrapper_78, &isr_wrapper_79,
   &isr_wrapper_80, &isr_wrapper_81, &isr_wrapper_82, &isr_wrapper_83,
   &isr_wrapper_84, &isr_wrapper_85, &isr_wrapper_86, &isr_wrapper_87,
   &isr_wrapper_88, &isr_wrapper_89, &isr_wrapper_90, &isr_wrapper_91,
   &isr_wrapper_92, &isr_wrapper_93, &isr_wrapper_94, &isr_wrapper_95,
   &isr_wrapper_96, &isr_wrapper_97, &isr_wrapper_98, &isr_wrapper_99,
   &isr_wrapper_100, &isr_wrapper_101, &isr_wrapper_102, &isr_wrapper_103,
   &isr_wrapper_104, &isr_wrapper_105, &isr_wrapper_106, &isr_wrapper_107,
   &isr_wrapper_108, &isr_wrapper_109, &isr_wrapper_110, &isr_wrapper_111,
   &isr_wrapper_112, &isr_wrapper_113, &isr_wrapper_114, &isr_wrapper_115,
   &isr_wrapper_116, &isr_wrapper_117, &isr_wrapper_118, &isr_wrapper_119,
   &isr_wrapper_120, &isr_wrapper_121, &isr_wrapper_122, &isr_wrapper_123,
   &isr_wrapper_124, &isr_wrapper_125, &isr_wrapper_126, &isr_wrapper_127,
   &isr_wrapper_128, &isr_wrapper_129, &isr_wrapper_130, &isr_wrapper_131,
   &isr_wrapper_132, &isr_wrapper_133, &isr_wrapper_134, &isr_wrapper_135,
   &isr_wrapper_136, &isr_wrapper_137, &isr_wrapper_138, &isr_wrapper_139,
   &isr_wrapper_140, &isr_wrapper_141, &isr_wrapper_142, &isr_wrapper_143,
   &isr_wrapper_144, &isr_wrapper_145, &isr_wrapper_146, &isr_wrapper_147,
   &isr_wrapper_148, &isr_wrapper_149, &isr_wrapper_150, &isr_wrapper_151,
   &isr_wrapper_152, &isr_wrapper_153, &isr_wrapper_154, &isr_wrapper_155,
   &isr_wrapper_156, &isr_wrapper_157, &isr_wrapper_158, &isr_wrapper_159,
   &isr_wrapper_160, &isr_wrapper_161, &isr_wrapper_162, &isr_wrapper_163,
   &isr_wrapper_164, &isr_wrapper_165, &isr_wrapper_166, &isr_wrapper_167,
   &isr_wrapper_168, &isr_wrapper_169, &isr_wrapper_170, &isr_wrapper_171,
   &isr_wrapper_172, &isr_wrapper_173, &isr_wrapper_174, &isr_wrapper_175,
   &isr_wrapper_176, &isr_wrapper_177, &isr_wrapper_178, &isr_wrapper_179,
   &isr_wrapper_180, &isr_wrapper_181, &isr_wrapper_182, &isr_wrapper_183,
   &isr_wrapper_184, &isr_wrapper_185, &isr_wrapper_186, &isr_wrapper_187,
   &isr_wrapper_188, &isr_wrapper_189, &isr_wrapper_190, &isr_wrapper_191,
   &isr_wrapper_192, &isr_wrapper_193, &isr_wrapper_194, &isr_wrapper_195,
   &isr_wrapper_196, &isr_wrapper_197, &isr_wrapper_198, &isr_wrapper_199,
   &isr_wrapper_200, &isr_wrapper_201, &isr_wrapper_202, &isr_wrapper_203,
   &isr_wrapper_204, &isr_wrapper_205, &isr_wrapper_206, &isr_wrapper_207,
   &isr_wrapper_208, &isr_wrapper_209, &isr_wrapper_210, &isr_wrapper_211,
   &isr_wrapper_212, &isr_wrapper_213, &isr_wrapper_214, &isr_wrapper_215,
   &isr_wrapper_216, &isr_wrapper_217, &isr_wrapper_218, &isr_wrapper_219,
   &isr_wrapper_220, &isr_wrapper_221, &isr_wrapper_222, &isr_wrapper_223,
   &isr_wrapper_224, &isr_wrapper_225, &isr_wrapper_226, &isr_wrapper_227,
   &isr_wrapper_228, &isr_wrapper_229, &isr_wrapper_230, &isr_wrapper_231,
   &isr_wrapper_232, &isr_wrapper_233, &isr_wrapper_234, &isr_wrapper_235,
   &isr_wrapper_236, &isr_wrapper_237, &isr_wrapper_238, &isr_wrapper_239,
   &isr_wrapper_240, &isr_wrapper_241, &isr_wrapper_242, &isr_wrapper_243,
   &isr_wrapper_244, &isr_wrapper_245, &isr_wrapper_246, &isr_wrapper_247,
   &isr_wrapper_248, &isr_wrapper_249, &isr_wrapper_250, &isr_wrapper_251,
   &isr_wrapper_252, &isr_wrapper_253, &isr_wrapper_254, &isr_wrapper_255 };

#endif
